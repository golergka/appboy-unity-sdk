namespace Appboy.Models {
  public enum ClickAction {
    NEWS_FEED,
    URI,
    NONE
  }
}

