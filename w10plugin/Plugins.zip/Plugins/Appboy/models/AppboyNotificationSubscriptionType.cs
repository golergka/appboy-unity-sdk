using System.Collections;

namespace Appboy.Models {
  public enum AppboyNotificationSubscriptionType {
    OPTED_IN = 0,
    SUBSCRIBED = 1,
    UNSUBSCRIBED = 2
  }
}
