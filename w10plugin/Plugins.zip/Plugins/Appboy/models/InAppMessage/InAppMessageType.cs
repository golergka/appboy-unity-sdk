namespace Appboy.Models.InAppMessage {
  public enum InAppMessageType {
    FULL,
    MODAL,
    SLIDEUP
  }
}
