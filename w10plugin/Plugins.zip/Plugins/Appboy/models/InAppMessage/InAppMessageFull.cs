using System;
using Appboy.Utilities;

namespace Appboy.Models.InAppMessage {
  public class InAppMessageFull : InAppMessageImmersiveBase {
    public InAppMessageFull() {
    }
  
    public InAppMessageFull(JSONClass json) : base(json) {
    }
  }
}

