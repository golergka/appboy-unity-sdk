namespace Appboy.Models {
  public enum SlideFrom {
    TOP,
    BOTTOM
  }
}

