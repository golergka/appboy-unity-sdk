namespace Appboy.Models {
  public enum DismissType {
    AUTO_DISMISS,
    SWIPE
  }
}

